<?php
namespace Espo\Modules\NestedTeams\Hooks\Team;

use Espo\ORM\Entity;

class TeamHooks extends \Espo\Core\Hooks\Base
{ 

    public function afterSave(Entity $entity, array $options=array())
    {
        
        // check if the created or updated Team belongs to a Parent Team
        if($entity->get("teamParentId")) { 
            // get the roles linked to the new or updated Team
            $targetRoles = $this->getEntityManager()->getRepository('Team')->findRelated($entity,'roles');
            // get the parent team object
            $parentTeamObject = $this->getEntityManager()->getRepository('Team')->where(['id'=>$entity->get("teamParentId")])->findOne();  
            // link the target Team roles to the Parent Team
            foreach($targetRoles as $targetRole) {
                $this->getEntityManager()->getRepository('Team')->relate($parentTeamObject, 'roles', $targetRole->get('id')); 
            }                        
        }
    }
       
}    

